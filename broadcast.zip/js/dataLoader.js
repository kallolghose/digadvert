window.onerror = function(err){
	alert(err)
}
var ip = 'localhost';
function initializeWindow1Data(channel,time,callback){
	getFileBasedOnTime(channel,time,function(data){
		callback(data);
	});
}

function initializeWindow2Data(channel,time,callback){
	getFileBasedOnTime(channel,time,function(data){
		callback(data);
	});
}

function initializeWindow3Data(channel,time,callback){
	getFileBasedOnTime(channel,time,function(data){
		callback(data);
	});
}

function initializeWindow4Data(channel,time,callback){
	getFileBasedOnTime(channel,time,function(data){
		callback(data);
	});
}

function initializeMasterWindow(channel,time,callback){
	getFileBasedOnTime(channel,time,function(data){
		callback(data);
	});
}