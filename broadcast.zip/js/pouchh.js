function Node(data, datatype, sTime, eTime, duration, foldername) {
    this.data = data;
    this.foldername = foldername;
	this.datatype = datatype;
	this.starttime = sTime;
	this.endtime = eTime;
	this.duration = duration;
    this.next = null;
}

/*var cLinkList = function CircularList() {
    this._length = 0;
    this.head = null;
	this.pHead = null;
}*/

var CircularList = function() {
    this._length = 0;
    this.head = null;
	this.pHead = null;
}

CircularList.prototype.add = function(data, datatype, sTime, eTime, duration, foldername){
	var new_node = new Node(data, datatype, sTime, eTime, duration, foldername);
	if(this.head==null)
	{
		new_node.next = new_node;
		this.head = new_node;
	}
	else
	{
		var currentNode = this.head;
		while(currentNode.next!=this.head)
		{
			currentNode = currentNode.next;
		}
		currentNode.next = new_node;
		new_node.next = this.head;
	}
};

CircularList.prototype.deleteList = function(){
	this.head = null;
	this.pHead = null;
};

CircularList.prototype.getNextNode = function(){
	if(this.head==null)
		return "";
	var nextNode = {};
	if(this.pHead==null)
	{
		this.pHead = this.head;
	}
	nextNode['data'] = this.pHead.data;
	nextNode['datatype'] = this.pHead.datatype;
	nextNode['starttime'] = this.pHead.starttime;
	nextNode['endtime'] = this.pHead.endtime;
	nextNode['duration'] = this.pHead.duration;
	nextNode['foldername'] = this.pHead.foldername;
	this.pHead = this.pHead.next;
	return nextNode;
};



var firstll = new CircularList();
var secondll = new CircularList();
var thirdll = new CircularList();
var fourthll = new CircularList();


var firstJSON = {};
var secondJSON = {};
var thirdJSON = {};
var fourthJSON = {};


var localDB = new PouchDB("digitaladvert_local2");
// var remoteDB = new PouchDB("http://10.13.67.174:5984/digitaladvert"); //Connected to google cloud
// var remoteDB = new PouchDB("http://35.201.239.214:5984/digitaladvert"); //Connected to google cloud
var remoteDB = new PouchDB("http://10.13.67.174:5984/digitaladvert"); //Connected to google cloud


//Function to handle searching of date

function mapFunction(doc)
{
	doc.planned.forEach(function(planneddisplay){
		emit(planneddisplay.starttime);
	});
}

//Register index to find the values of fields
localDB.createIndex({
  index: {
    fields : ['type','foldername'],
	name :"typeandfolder",
	ddoc : "typeandfolder",
	type : "json"
  }
}).then(function (result) {
  console.log("Create Index : " + JSON.stringify(result));
}).catch(function (err) {
  console.log("Error in Create Index : " + JSON.stringify(err));
});

localDB.createIndex({
  index: {
    fields : ['type','starttime','endtime'],
	name :"plannedchannel",
	ddoc : "plannedchanneldoc",
	type : "json"
  }
}).then(function (result) {
  console.log("Create Index : " + JSON.stringify(result));
}).catch(function (err) {
  console.log("Error in Create Index : " + JSON.stringify(err));
});

localDB.createIndex({
  index: {
    fields : ['type','foldername','starttime','endtime'],
	name :"plannedfolderchannel",
	ddoc : "plannedfolderchanneldoc",
	type : "json"
  }
}).then(function (result) {
  console.log("Create Index : " + JSON.stringify(result));
}).catch(function (err) {
  console.log("Error in Create Index : " + JSON.stringify(err));
});

//Function to handle live syncing
// var syncHandler = remoteDB.replicate.to(localDB,{
var syncHandler = PouchDB.sync(localDB,remoteDB,{
	live:true,
	retry:true
}).on('change',function(change){
	// console.log(JSON.stringify(change));
	initializeChannel1();
	initializeChannel2();
	initializeChannel3();
	initializeChannel4();
})
.on('paused',function(info){
	//console.log("Data Pause");
})
.on('active', function(info){
	//console.log("Data active");
})
.on('error', function(info){
	console.log("Data error");
});

/*
	Function to read data from local database on startup
*/
//1.Read from first_folder
function initializeChannel1()
{
	firstll = new CircularList();
	localDB.find(
		{
		selector:{$and : [{"type":{$eq: "general"}},{"foldername":{$eq:"first"}}]}
		}
	).then(function(result)
	{
		firstJSON['resultSet'] = result.docs;
		for(var i=0;i<result.docs.length;i++)
		{
			var file = result.docs[i];
			firstll.add(file.data, file.datatype, file.starttime, file.endtime, file.duration, file.foldername);
		}
		console.log("Initializing Channel 1...");
	}).catch(function(err){
	
	});
}

function initializeChannel2()
{
	secondll = new CircularList();
	localDB.find(
		{
		selector:{$and : [{"type":{$eq: "general"}},{"foldername":{$eq:"second"}}]}
		}
	).then(function(result){
		secondJSON['resultSet'] = result.docs;
		for(var i=0;i<result.docs.length;i++)
		{
			var file = result.docs[i];
			secondll.add(file.data, file.datatype, file.starttime, file.endtime, file.duration, file.foldername);
		}
		console.log("Initializing Channel 2...");
	}).catch(function(err){
	
	});
}

function initializeChannel3()
{
	thirdll = new CircularList();
	localDB.find(
		{
		selector:{$and : [{"type":{$eq: "general"}},{"foldername":{$eq:"third"}}]}
		}
	).then(function(result){
		thirdJSON['resultSet'] = result.docs;
		for(var i=0;i<result.docs.length;i++)
		{
			var file = result.docs[i];
			thirdll.add(file.data, file.datatype, file.starttime, file.endtime, file.duration,  file.foldername);
		}
		console.log("Initializing Channel 3...");
	}).catch(function(err){
	
	});
}

function initializeChannel4()
{
	fourthll = new CircularList();
	localDB.find(
		{
		selector:{$and : [{"type":{$eq: "general"}},{"foldername":{$eq:"fourth"}}]}
		}
	).then(function(result){
		fourthJSON['resultSet'] = result.docs;
		for(var i=0;i<result.docs.length;i++)
		{
			var file = result.docs[i];
			fourthll.add(file.data, file.datatype, file.starttime, file.endtime, file.duration, file.foldername);
		}
		console.log("Initializing Channel 4...");
	}).catch(function(err){
	
	});
}

initializeChannel1();
initializeChannel2();
initializeChannel3();
initializeChannel4();


function getFileBasedOnTime(folderName,time,callback){
	
	localDB.find(
		{
		selector:{
					$and:[
							{'type':{$eq:"sos"}},
							{'starttime':{$lt:time}},
							{'foldername':{$eq:folderName}},
							{'endtime':{$gte:time}}
						 ]
				 }
		}
	).then(function(result)
	{
		if(result.docs.length!=0)
		{
			nextFile = result.docs[0];
			callback(nextFile);
		}
		else
		{
			localDB.find(
						{
							selector:{
										$and:[
												{'type':{$eq:"planned"}},
												{'foldername':{$eq:folderName}},
												{'starttime':{$lt:time}},
												{'endtime':{$gte:time}}
											 ]
									 }
						}
				   ).then(function(result)
					{
						var nextFile = {};
						if(result.docs.length!=0)
						{
							
							nextFile = result.docs[0];
						}
						else
						{
							if(folderName == "first")
							{
								nextFile = firstll.getNextNode();
							}
							else if(folderName == "second")
							{
								nextFile = secondll.getNextNode();
							}
							else if(folderName == "third")
							{
								nextFile = thirdll.getNextNode();
							}
							else if(folderName == "fourth")
							{
								nextFile = fourthll.getNextNode();
							}
						}
						callback(nextFile);
					})
					.catch(function(err){										
						console.log(err);
						callback({"Error" : err});
					});
		}
	}).catch(function(err){
		console.log(err);
		callback({"Error" : err});
	});
}