var interval1 = 1000;
var interval2 = 1000;
var interval3 = 1000;
var interval4 = 1000;
var myTimeout;
var masterPlan;
var masterPlanInterval = 6000;
// var URL = "http://localhost/broadcast";
var URL = "http://localhost:5100";

var app = {};
app.imageElements = {};
app.videoElements = {};
app.imageElements.image1 = '<img id="img1" class="imgs"></img>';
app.imageElements.image2 = '<img id="img2" class="imgs"></img>';
app.imageElements.image3 = '<img id="img3" class="imgs"></img>';
app.imageElements.image4 = '<img id="img4" class="imgs"></img>';
app.imageElements.image5 = '<img id="img5" class="imgs"></img>';

app.videoElements.video1 = '<video id="vid1" class="vids" width="100%" height="100%"></video>';
app.videoElements.video2 = '<video id="vid2" class="vids" width="100%" height="100%"></video>';
app.videoElements.video3 = '<video id="vid3" class="vids" width="100%" height="100%"></video>';
app.videoElements.video4 = '<video id="vid4" class="vids" width="100%" height="100%"></video>';
app.videoElements.video5 = '<video id="vid5" class="vids" width="100%" height="100%"></video>';


// 7982929743


window.onload = function(){
	window.onerror = function(err){
		alert(err)
	}

	function loadFullScreenVideo(data){
		$("div.contentHolder5").empty();
		$("div.contentHolder5").append(app.videoElements.video5);
		$("#vid5").attr('src', URL + "/" + data.foldername + "/" + data.data);
		$("#vid5").get(0).play();
		$("#img5").hide();
		$("#vid5").show();
		$("div.singleContent").show();
		$("div.multiContent").hide();
	}

	function loadFullScreenImage(data){
		$("div.contentHolder5").empty();
		$("div.contentHolder5").append(app.imageElements.image5);
		$("#img5").attr('src', URL + "/" + data.foldername + "/" + data.data);
		$("#vid5").hide();
		$("#img5").show();
		$("div.singleContent").show();
		$("div.multiContent").hide();
	}

	function loadWindow1(){
		initializeWindow1Data('first',getCurrentISODate(),function(data){
			if(data.datatype == 'video'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder1").empty();
					$("div.contentHolder1").append(app.videoElements.video1);
					$("#vid1").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid1").get(0).play();
					$("#img1").hide();
					$("#vid1").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 3){
				// 	loadFullScreenVideo(data);
				// }
			}else if(data.datatype == 'image'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder1").empty();
					$("div.contentHolder1").append(app.imageElements.image1);
					$("#img1").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid1").hide();
					$("#img1").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 3){
				// 	loadFullScreenImage(data);
				// }
			}else if(data.datatype == 'text'){
				$("div.contentHolder1>div.marquee").empty();
				$("div.contentHolder1").empty();
				$("div.contentHolder1").append('<div class="warningText">'+ data.data +'</div>');
			}
			interval1=parseInt(data.duration)*1000
			myTimeout = setTimeout(function(){
				// if(data.priority != 1){ $("div.multiContent").show(); $("div.singleContent").hide();}else{$("div.singleContent").hide();}
				initializeWindow1(parseInt(data.duration)*1000);
			},interval1);
		});
	}

	function loadWindow2(){
		initializeWindow2Data('second',getCurrentISODate(),function(data){
			if(data.datatype == 'video'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder2").empty();
					$("div.contentHolder2").append(app.videoElements.video2);
					$("#vid2").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid2").get(0).play();
					$("#img2").hide();
					$("#vid2").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenVideo(data);
				// }
			}else if(data.datatype == 'image'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder2").empty();
					$("div.contentHolder2").append(app.imageElements.image2);
					$("#img2").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid2").hide();
					$("#img2").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenImage(data);
				// }
			}else if(data.datatype == 'text'){
				$("div.contentHolder2>div.marquee").empty();
				$("div.contentHolder2").empty();
				$("div.contentHolder2").append('<div class="warningText">'+ data.data +'</div>');
			}
			interval2=parseInt(data.duration)*1000
			myTimeout = setTimeout(function(){
				// if(data.priority != 1){ $("div.multiContent").show(); $("div.singleContent").hide();}else{$("div.singleContent").hide();}
				initializeWindow2(parseInt(data.duration)*1000);
			},interval2);
		});
	}

	function loadWindow3(){
		initializeWindow3Data('third',getCurrentISODate(),function(data){
			if(data.datatype == 'video'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder3").empty();
					$("div.contentHolder3").append(app.videoElements.video3);
					$("#vid3").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid3").get(0).play();
					$("#img3").hide();
					$("#vid3").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenVideo(data);
				// }
			}else if(data.datatype == 'image'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder3").empty();
					$("div.contentHolder3").append(app.imageElements.image3);
					$("#img3").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid3").hide();
					$("#img3").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenImage(data);
				// }
			}else if(data.datatype == 'text'){
				$("div.contentHolder3>div.marquee").empty();
				$("div.contentHolder3").empty();
				$("div.contentHolder3").append('<div class="warningText">'+ data.data +'</div>');
			}
			interval3=parseInt(data.duration)*1000
			myTimeout = setTimeout(function(){
				// if(data.priority != 1){ $("div.multiContent").show(); $("div.singleContent").hide();}else{$("div.singleContent").hide();}
				initializeWindow3(parseInt(data.duration)*1000);
			},interval3);
		});
	}

	function loadWindow4(){
		initializeWindow4Data('fourth',getCurrentISODate(),function(data){
			// data.datatype = "text"
			// data.data = "this is testing advert line";
			// data.duration = "40";
			if(data.datatype == 'video'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder4").empty();
					$("div.contentHolder4").append(app.videoElements.video4);
					$("#vid4").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid4").get(0).play();
					$("#img4").hide();
					$("#vid4").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenVideo(data);
				// }
			}else if(data.datatype == 'image'){
				// if(data.priority == 2 || data.priority == 3){
					$("div.contentHolder4").empty();
					$("div.contentHolder4").append(app.imageElements.image4);
					$("#img4").attr('src', URL + "/" + data.foldername + "/" + data.data);
					$("#vid4").hide();
					$("#img4").show();
					// $("div.singleContent").hide();
					// $("div.multiContent").show();
				// }
				// else if(data.priority == 1){
				// 	loadFullScreenImage(data);
				// }
			}else if(data.datatype == 'text'){
				$("div.contentHolder4").empty();
				$("div.contentHolder4>div.marquee").empty();
				$("div.contentHolder4").append('<div class="marquee"></div>');
				$("div.contentHolder4>div.marquee").append('<p>' + data.data + '</p>');
			}
			interval4=parseInt(data.duration)*1000
			myTimeout = setTimeout(function(){
				// if(data.priority != 1){ $("div.multiContent").show(); $("div.singleContent").hide();}else{$("div.singleContent").hide();}
				initializeWindow4(parseInt(data.duration)*1000);
			},interval4);
		});
	}

	function initializeWindow1(interval){
		loadWindow1();
	};

	function initializeWindow2(interval){
		loadWindow2();
	};

	function initializeWindow3(interval){
		loadWindow3();
	};

	function initializeWindow4(interval){
		loadWindow4();
	};

	initializeWindow1(interval1);
	initializeWindow2(interval2);
	initializeWindow3(interval3);
	initializeWindow4(interval4);

	function checkForMasterPlan(){
		initializeMasterWindow('sos',getCurrentISODate(),function(data){
			if(data.datatype){
				if(data.datatype == "video"){
					loadFullScreenVideo(data);
				}else if(data.datatype == "image"){
					loadFullScreenImage(data);
				}else if(data.datatype == 'text'){
					$("div.contentHolder5>div.marquee").empty();
					$("div.contentHolder5").empty();
					$("div.contentHolder5").append('<div class="warningText">'+ data.data +'</div>');
				}
				$("div.multiContent").hide();
				$("div.singleContent").show();
			}else{
				 $("div.multiContent").show();
				 $("div.singleContent").hide();
			}
		})
	}

	masterPlan = setInterval(function(){
		checkForMasterPlan();
	},masterPlanInterval);


	function getCurrentISODate(){
		// var tzoffset = (new Date()).getTimezoneOffset() * 60000;
		// return localISOTime = (new Date(Date.now() - tzoffset)).toISOString().slice(0,-1) + "Z";
		return new Date().toISOString()
	}


	$("#vid3").on('ended', function() {
	    // $("#vid3").hide();
	    // $("#img3").show();
	    $("#vid3")[0].src = 'videos/vid1.mp4';
	    $("#vid3")[0].load();
	    $("#vid3")[0].play();
	});

	$("#vid2").on('ended', function() {
	    $("#vid2").hide();
	    $("#img2").show();
	});
}