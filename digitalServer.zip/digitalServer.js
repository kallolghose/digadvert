var host = "10.13.69.91";
var port = 2000;
var express = require("express");

var app = express();
app.use(express.static(__dirname+"/DigitalAdvert")); 
app.get("*", function(request, response){ 
response.sendfile('./DigitalAdvert/index.html');
});

app.listen(port, host);
console.log("Web Server Started : " + port);

//<base href="/DigitalAdvert" >